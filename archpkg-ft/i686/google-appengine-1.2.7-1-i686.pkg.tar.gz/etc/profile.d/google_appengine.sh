#!/bin/bash

export PATH=$PATH:/opt/google-appengine
export PYTHONPATH=$PYTHONPATH:/opt/google-appengine
