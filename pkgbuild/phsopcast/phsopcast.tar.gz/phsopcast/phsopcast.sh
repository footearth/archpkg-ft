#!/bin/bash
#
#=======================
#   name:phsopcast
#   auther:footearth
#=======================
#

Menu() {
	clear
	echo ""
	Proctest
	echo "            $proc_back              $proc_front"
	echo ""
	echo "            ================== Ph-Sopcast =================="
	echo ""
	echo "            凤凰卫视:"
	echo "            phzh  凤凰卫视中文台    phzx  凤凰卫视咨询台"
	echo "            phdy  凤凰卫视电影台"
	echo ""
	echo "            其他常用:"
	echo "            播放器:    [M]player  [G]nome-mplayer"
	echo "            ------------------------------------------------"
#	echo "                L|list      详细频道列表及代码"
	echo "                C|clean     清除后台进程"
	echo "                Q|quit      推出控制台"
	echo "            ================================================"
	echo -n "                请输入:"
	read Key
	key
}

Set_channels() {
	phzh=sop://211.152.36.38:3912/6004 #凤凰卫视中文台
	phzx=sop://211.152.36.38:3912/6005 #凤凰卫视资讯台
	phdy=sop://211.152.36.38:3912/6011 #凤凰卫视电影台
}

Play() {
	tvdir="http://localhost:8800"
	if [ "$1" == "mplayer" ]
	then
		mplayer $tvdir < /dev/null > /dev/null 2>&1 &
	elif [ "$1" == "gnome-mplayer" ]
	then
		gnome-mplayer $tvdir &
	fi
}

Proctest() {
	proc_back="后台没有运行"
	proc_front="前台没有运行"
	if [ -n "`ps ax | grep sp-sc | grep -v grep`" ]
	then
		proc_back="后台运行正常"
	fi
	if [ -n "`ps ax | grep http://localhost:8800 | grep -v grep`" ]
	then
		proc_front="前台运行正常"
	fi
}

Clean() {
	for Proc in sp-sc mplayer gnome-mplayer
	do
		while [ -n "`ps ax | grep $Proc | grep -v grep`" ]
		do
			sudo killall $Proc >/dev/null 2>&1
		done
	done
}

Back() {
	Clean
	Menu
}

Quit() {
	Clean
	exit
}

key() {

	Set_channels

	[[ -n $Key ]] || Menu

	case "$Key" in
	C|clean)
		Back
	;;
	Q|quit)
		Quit
	;;
	M|mplayer)
		Play mplayer
		Menu
	;;
	G|gnome-mplayer)
		Play gnome-mplayer
		Menu
	;;
	*)
		eval channel=\$$Key
		[ -n "$channel" ] || Menu
		Clean
		sp-sc $channel 8900 8800 2>&1 >/dev/null &
		Menu
	;;
	esac

}

Menu
