#!/bin/bash

# WORK=`dirname $0`
WORK=/usr/share/rmirrors
# echo WORK=$WORK

# sed -n /^Server/p $targe | sort | uniq
 rankmirrors -v -n 25 $WORK/mirrorlist | sed -n /^Server/p > ~/.mirrorlist
 cat $WORK/arch.org >> ~/.mirrorlist

 sudo cp ~/.mirrorlist /etc/pacman.d/mirrorlist
