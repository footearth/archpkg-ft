#!/bin/bash

export PATH=$PATH:/opt/google-appengine-java/bin

